// Vercel Serverless Function — puente seguro hacia OpenRouter
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Método no permitido' });
  const key = process.env.OPENROUTER_API_KEY;
  if (!key) return res.status(500).json({ error: 'Falta configurar OPENROUTER_API_KEY en Vercel' });
  try {
    const { mode, image, messages, contexto } = req.body || {};
    let body;
    if (mode === 'extract') {
      if (!image) return res.status(400).json({ error: 'Falta la imagen' });
      body = { model: 'openai/gpt-4o-mini', messages: [{ role: 'user', content: [
        { type: 'text', text: 'Extrae de esta factura venezolana y devuelve SOLO JSON, sin markdown ni explicaciones, con estas claves: tipo ("Compra / gasto" o "Venta / ingreso"), fecha (YYYY-MM-DD), emisor, rif, receptor, rif_receptor, numero_factura, base (número), iva (número), total (número), categoria ("Publicidad","Equipos" u "Otros"). Si un dato no aparece, usa cadena vacía para textos y 0 para números. No inventes datos.' },
        { type: 'image_url', image_url: { url: image } }
      ]}]};
    } else if (mode === 'chat') {
      const system = 'Eres Fénix, asistente contable para emprendedores en Venezuela. Responde en español, breve, claro y accionable, máximo 180 palabras. Ayuda con IVA, ISLR, deducibilidad, organización de gastos, facturas y registros. Si falta información importante, haz una pregunta breve antes de recomendar. No inventes cifras, tasas ni normas. No tienes acceso a información privada de terceros. Contexto actual: ' + (contexto || '') + ' Recuerda que Fénix es apoyo y no sustituye a un contador público colegiado antes de declarar ante el SENIAT.';
      body = { model: 'openai/gpt-4o-mini', messages: [{ role: 'system', content: system }].concat(Array.isArray(messages) ? messages.slice(-10) : []) };
    } else return res.status(400).json({ error: 'Modo no válido' });
    const r = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST', headers: { 'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json' }, body: JSON.stringify(body)
    });
    const j = await r.json();
    if (!r.ok) return res.status(r.status).json({ error: j.error?.message || 'Error de OpenRouter' });
    if (mode === 'extract') {
      const txt = j.choices?.[0]?.message?.content || '';
      const m = txt.match(/\{[\s\S]*\}/);
      let data = {}; try { data = JSON.parse(m[0]); } catch (e) { return res.status(500).json({ error: 'No se pudo interpretar la respuesta de la IA' }); }
      return res.status(200).json({ data });
    } else {
      return res.status(200).json({ respuesta: j.choices?.[0]?.message?.content || '' });
    }
  } catch (e) { return res.status(500).json({ error: 'Error interno del puente de IA' }); }
}
